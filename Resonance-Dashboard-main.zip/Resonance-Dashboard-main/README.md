# Resonance
Engine health monitoring and early warning system framework

Getting started :
=================
  Prerequisties
  
  Windows 
 --------------
     1. Postgresql and associated tools need to be installed. 
          a. Go to https://www.postgresql.org/download/windows/
          b. Download the installer or the zip archives of the binaries
          c. Follow the steps in the installer to install postgresql 15.3 or above. 
             You should enable postgis extension as well in the installer. 
             Alsoo enable pgbouncer, pgAdmin and psql as well.
             
    2. Install node on windows machine using the following command  
       # installs nvm (Node Version Manager)
       curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash

       # download and install Node.js (you may need to restart the terminal)
       nvm install 18

       # verifies the right Node.js version is in the environment
       node -v # should print `v18.19.x (x = any number)`

       # verifies the right NPM version is in the environment
       npm -v # should print `10.8.0
    
    3. Python 3 installation 
      Step 1: Visit the Python Website and Navigate to the Downloads Section

      First and foremost step is to open a browser and type Python Download or paste link (https://www.python.org/downloads/)

      Step 2: Choose the Python Version (3.8 and above)
      Click on the version you want to download. – Python 3.8.x (the latest stable release as of now is Python 3.12.3).
      
      Step 3: Download the Python Installer
      Once the download is complete, run the installer program.`

      Run the Python Installer for how to install Python on the Windows downloads folder 
      Make sure to mark Add Python to PATH otherwise you will have to do it explicitly. It will start installing Python on Windows. 

    4. Open a windows power shell in administrator mode 
       Go inside ResonanceDashboard/src/api
       
       Copy the .env.sample to .env and change the DB_NAME other than postgres according to your choice.
       Here as a sample you see it is given as resonance_db. 
       
       Run npm install
       Run npm run dev (npm run start) 

    5. Open a windows power shell in administrator mode 
       Go inside ResonanceDashboard/src/ui

       Edit the file src/Pages/apiConfig.js and edit the line 
       export const SERVER_IP = window._env_?.REACT_APP_HOST_IP_ADDRESS 
       to 
       export const SERVER_IP = window._env_?.REACT_APP_HOST_IP_ADDRESS ? window._env_?.REACT_APP_HOST_IP_ADDRESS : "http://localhost:3001"

       This will be fixed.
       
       Run npm install
       Run npm run start

    6. You can now see the application running on the browser http://localhost:3000 .
        Login : admin@resonance.com
        Password: admin123
        

