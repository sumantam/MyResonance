require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const sequelize = require("./app/utils/database");
const domain = process.env.CLIENT_ORIGIN || "http://localhost:3000";
const { createDatabase } = require("./app/utils/createDB");
const routes = require("./app/routes/index");
const PORT = process.env.PORT || 3000

var corsOptions = {
  origin: domain,
  allowedHeaders: ["api_key", "Authorization", "*"],
};

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test the server
app.get("/", (req, res) => {
  res.json({ data: "Welcome to Resonance Dashboard backend checked" });
});

(async () => {
  try {
    const DBRes = await createDatabase();
    if (DBRes) {
      app.use("/api", routes);
      let syncVal = await sequelize.sync();

      app.listen(PORT, () => {
        console.log(`Server is running on PORT ${PORT}`);
      });
    } else {
      console.log("no database found");
    }
  } catch (error) {
    console.log("serverjs error");
    return null;
  }
})();
