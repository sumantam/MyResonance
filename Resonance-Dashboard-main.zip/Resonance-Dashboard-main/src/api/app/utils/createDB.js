const dotenv = require('dotenv');
const path = require('path');

const filename = path.basename(__filename);
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

const dbConfig = require("../config/db.config.js");

const pg = require('pg')

const client = new pg.Client ({
	host: dbConfig.HOST,
	user: dbConfig.USER,
	password: dbConfig.PASSWORD,
	port: dbConfig.port
});

const pool = new pg.Pool({
    user: dbConfig.USER,
    host: dbConfig.HOST,
    database: dbConfig.DB,
    password: dbConfig.PASSWORD,
    port: dbConfig.PORT}
);

const createDatabase = async() => {
	try {
		console.log("It is done upto here " + filename);
		await client.connect();
		const result = await client.query("SELECT 1 FROM pg_database where datname = '" + dbConfig.DB + "'");
		if (result.rowCount == 0) {
			console.log("Needs to create a new database " + filename);
			await client.query('CREATE DATABASE ' + dbConfig.DB);
			console.log("Successful in creating a new database " + filename);
		} else {
			console.log("Database exists");
		}

		return true;
	} catch (error) {
		console.error(error.stack + "createDataBase");
		return false;
	} finally {
		await client.end();
	}
}

module.exports = {
    createDatabase : createDatabase,
     pool: pool
}
