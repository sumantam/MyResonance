const { DataTypes } = require("sequelize");
const sequelize = require('../utils/database')

const User = sequelize.define("User", {
  userid: {
    type: DataTypes.INTEGER,
    autoIncrement: true
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  role: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "User",
  },
  responsibility: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "Operator",
  },
  designation: {
    type: DataTypes.STRING,
    defaultValue: "Senior Engineer"
  },
  countryCode: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "+91",
  },
  mobileNumber: {
    type: DataTypes.STRING,
    allowNull: false
  },
  img: {
    type: DataTypes.JSONB,
    defaultValue: {},
  },
  address: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  // currentEquipmentType: {
  //   type: DataTypes.UUID,
  //   references: {
  //     model: "equipment_type",
  //     key: "id",
  //   },
  // },
  // currentEquipment: {
  //   type: DataTypes.UUID,
  //   references: {
  //     model: "equipment",
  //     key: "id",
  //   },
  // },
});

module.exports = User
