const process = require('process');
const { DataTypes, Sequelize } = require("sequelize");
const sequelize = require('../utils/database')
//const User = require('./user.model.js')

const Relation = sequelize.define("Relation", {
  userEmail: {
    type: DataTypes.STRING,
    allowNull: false,
    //references: public."Users",
    //referencesKey: 'email'
  },
  userName: {
      type: DataTypes.STRING,
      allowNull: false
    },
//  userRole: {
//    type: DataTypes.STRING,
//    allowNull: false,
//    defaultValue: "USER",
//  },
//  responsibility: {
//    type: DataTypes.STRING,
//    allowNull: false,
//    defaultValue: "OPERATOR",
//  },
  managerEmail: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: 'HR',
    //references: public."Users",
    //referencesKey: 'email'
  },
  managerName: {
    type: DataTypes.STRING,
    allowNull: true
  }
//  managerRole: {
//    type: DataTypes.STRING,
//    allowNull: false,
//    defaultValue: "SUPERVISOR",
//  }
});

//Relation.belongsTo(User, { foreignKey: 'email' });

module.exports = Relation;
