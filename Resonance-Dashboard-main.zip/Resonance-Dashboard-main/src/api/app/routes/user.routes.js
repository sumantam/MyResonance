const users = require("../controllers/users.controller.js");
const relations = require("../controllers/relation.controller.js");

var router = require("express").Router();

// Create a new User
// router.post("/", IsAdmin, users.create);
router.post("/", users.create);

// Create a new Relation
router.post("/relation", relations.create);

// Retrieve all User
router.get("/", users.findAll);

// Search Users having matched sub-string of username
router.get("/search", users.searchUser);

// Retrieve a single User with their emailPOST
router.get("/:email", users.findOne);

// Update a User with user with their email
router.put("/:email", users.updateUser);

// Delete a User with username
router.delete("/:email", users.removeUser);

// Get users by their responsibility
router.get("/responsibility/search", users.getUserByResponsibility);

module.exports = router;
