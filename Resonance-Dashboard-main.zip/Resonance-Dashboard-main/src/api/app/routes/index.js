const router = require('express').Router();
const AuthMiddleware = require('../middlewares/auth')
const usersRoutes = require('./user.routes')

// Auth middleware
router.use(AuthMiddleware);

router.use('users', usersRoutes)
// router.use('admin', adminRoutes)
// router.use('usr', usrRoleRoutes)

module.exports = router;