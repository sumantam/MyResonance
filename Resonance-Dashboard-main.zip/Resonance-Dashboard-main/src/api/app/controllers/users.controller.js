const User = require("../models/user.model");
const { Op } = require("sequelize");

// Create and save a new user
exports.create = async (req, res) => {
  console.log(req.body);

  const user = {
    email: req.body.email,
    name: req.body.name,
    role: req.body.role,
    responsibility: req.body.responsibility,
    designation: req.body.designation,
    countryCode: req.body.countryCode,
    mobileNumber: req.body.mobileNumber,
    img: null,
    address: req.body.address,
    currentEquipmentType: null,
    currentEquipment: null,
  };

  try{
  const Result= await User.findByPk(user.email);
  if (Result === null) {
    console.log('Not found!');
    User.create(user, { omitNull: false })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
  } else {
    console.log('found!'); // true
    res.status(1062).send("Duplicate entry violating a primary key constraint for a column.");
    // Its primary key is 123
  }
}
  catch(err){
    res.status(500).send({
      message: err.message || "Some critical error occurred while creating the User.",
    });
  }
  
  // console.log(db.models)
  // const Result= await User.findByPk(user.email);
  // if (Result === null) {
  //   console.log('Not found!');
  //   User.create(user, { omitNull: false })
  //   .then((data) => {
  //     res.send(data);
  //   })
  //   .catch((err) => {
  //     res.status(500).send({
  //       message: err.message || "Some error occurred while creating the User.",
  //     });
  //   });
  // } else {
  //   console.log('Not found!'); // true
  //   res.status(1062).send("Duplicate entry violating a primary key constraint for a column.");
  //   // Its primary key is 123
  // }
  // save user in database
  
};

// Get all users info
exports.findAll = (req, res) => {
  // save user in database
  User.findAll()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
};

// find by primary Key
exports.findOne = (req, res) => {
  const email = req.params.email;
  //console.log(username)
  // save user in database
  User.findByPk(email)
    .then((data) => {
      console.log("findOne called")
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
};

// find by username
exports.findOne = (req, res) => {
  const email = req.params.email;
  console.log(email);

  User.findOne({ where: { email } })
    .then((data) => {
      //console.log(data)
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
};

// Delete by user email
exports.removeUser = (req, res) => {
  const email = req.params.email;
  console.log(`Deleting user: ${email}`)

  User.destroy({ where: { email: email } })
    .then(function () {
      //console.log(data)
      res.status(200).send(`user ${email} removed successfuly`);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing the User.",
      });
    });
};

// Update by user email
exports.updateUser = (req, res) => {
  const email = req.body.email;
  const user = {
    name: req.body.name,
    role: req.body.role,
    responsibility: req.body.responsibility,
    countryCode: req.body.countryCode,
    mobileNumber: req.body.mobileNumber,
    email: req.body.email,
    designation: req.body.designation,
    img: null,
    address: req.body.address,
    currentEquipmentType: null,
    currentEquipment: null,
  };

  // //console.log(`Updating user: ${username}`)
  // User.findOne({ where: {username} })
  //    .then((data) => {
  //     res.status(200).send(`user ${username} 1 info updated successfuly`);
  //     //console.log("Response data")
  //     //console.log(data.dataValues.role)
  //     const userTemp = {}
  //     for (const key in data.dataValues) {
  //       console.log()
  //     }

  //     console.log(userTemp)
  //    })
  //    .catch((err) => {
  //      res.status(500).send({
  //        message: err.message || "Some error occurred while creating the User.",
  //      });

  // });

  User.update(user, { where: {email:email} })
    .then((data) => {
      console.log("Returned result after update",data[0])
      if(data[0]===1){
        res.status(200).send(`user ${email} info updated successfuly`);
      }
      else{
        res.status(201).send(`user ${email} not found in the database`);
      }
      
    })
    .catch((err) => {
      //console.log(err.message)
      res.status(500).send({
        message:
          err.message || "Some error occurred while Updating the User info.",
      });
    });
};

// get all matched substring usernames
exports.searchUser = (req, res) => {
  const { q } = req.query;
  console.log(q)

  User.findAll({
    where: {
      email: {
        [Op.iLike]: `%${q}%`,
      },
    },
  })
    .then((data) => {
      //console.log(data)
      res.status(200).send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing the User.",
      });
    });
};

// get all matched substring usernames
exports.getUserByResponsibility= (req, res) => {
  const {q} = req.query;
  console.log(q)

  User.findAll({
    where: {responsibility: q},
  })
    .then((data) => {
      //console.log(data)
      res.status(200).send(data);
    })
    .catch((err) => {
	 console.log("Error with responsibility")
      res.status(500).send({
        message: err.message || "Some error occurred while getting the User by responsibility.",
      });
    });
};
