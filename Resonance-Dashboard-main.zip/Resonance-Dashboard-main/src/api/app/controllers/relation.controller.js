
// const db = require('../models/user.model')
console.log("Before relation");
const Relation_model = require("../models/relation.model");
console.log("After relation");
//const { Op } = require("sequelize");

// Create and save a new relation
exports.create = async (req, res) => {
  //console.log(req.body);


  try {
	  const relations = []; 
   
    const user      = req.body.user;
    const mgrList   = req.body.mgrList;
    const reporteeList= req.body.reporteeList;
    
    for (let i = 0; i < mgrList.length; i++) {
    	
        mgrEmail = mgrList[i].email;
        mgrName  = mgrList[i].name;
	relations.push({userEmail: user.email, userName: user.name, managerEmail: mgrEmail,managerName: mgrName});
        //rel.newRelation(user.email, user.name, mgrEmail, mgrName);
	}

    // find the list of managers for the user
    for (let i = 0; i < reporteeList.length; i++) {
    	
        reporteeEmail = reporteeList[i].email;
        reporteeName  = reporteeList[i].name;
	relations.push({userEmail: reporteeEmail, userName: reporteeName, managerEmail: user.email,managerName: user.name});
	}
    console.log(relations);
    // find the list of reportees for the user
     Relation_model.bulkCreate(relations)
  .then(() => {
    res.status(200).send(relations);
    console.log('Relations created successfully');
  })
  .catch((error) => {
  	res.status(500).send("Error creating relation");
	  console.error('Error creating relations:', error);
  });
  }
  catch(err){
    res.status(500).send({
      message: err.message || "Some critical error occurred while creating the User.",
    });
  }
};

