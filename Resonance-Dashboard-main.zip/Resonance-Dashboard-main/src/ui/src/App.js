import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Pages/Login/Login';
import UserManagement from './Pages/UserManagement/UserManagement';
import UserForm from './Pages/UserForm';
import ForgotPassword from './Pages/Login/ForgotPassword';
import  SystemDefinition  from './Pages/SystemDefinition/SystemDefinition';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/forgotPassword" element={<ForgotPassword/>}/>
        <Route path="/userManagement" element={<UserManagement />} />
        <Route path="/userForm" element={<UserForm/>}/>
        <Route path="/system-definition" element={<SystemDefinition/>}/>
      </Routes>
    </Router>
  );
};

export default App;


