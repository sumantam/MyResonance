import React, { useState } from "react";
import { connect } from "react-redux";
import { api_key } from "../api_key";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Dialog,
  DialogActions,
  DialogTitle,
  DialogContent,
  Button,
  Menu,
  MenuItem,
  IconButton,
  Typography,
  Modal,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  CardHeader,
  FormControl,
  Avatar,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { useSelector } from "react-redux";

import { useDispatch } from "react-redux";
import { fetchUsers, deleteUser, updateUser } from "../reducers/formReducer";

import { styled } from "@mui/system";

import { useEffect } from "react";
import { EditedUserModal } from "./EditUserModal";

const UserModal = ({ user, open, onClose }) => {
  console.log(user);
  const CustomModal = styled(Modal)(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  }));
  const ModalContent = styled("div")(({ theme }) => ({
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "400px",
    backgroundColor: "#F0F0FF",
    boxShadow: "0 2px 10px rgba(0, 0, 0, 0.2)",
    outline: "none",
    borderRadius: theme.shape.borderRadius,
    padding: theme.spacing(4),
  }));
  return (
    <CustomModal open={open} onClose={onClose}>
      <ModalContent sx={{ width: "600px", height: "500px" }}>
        <Card sx={{ maxWidth: 600, maxHeight: 450 }}>
          <div
            style={{
              display: "flex",
              alignItems: "baseline",
            }}
          >
            <Avatar
              alt="User Avatar"
              src="/path/to/default-avatar.jpg"
              sx={{
                marginRight: 1,
                marginLeft: "1vh",
                height: "30vh",
                width: "30vh",
                marginTop: "1vh",
              }}
            />
            <CardHeader
              title={
                <Typography
                  variant="h6"
                  sx={{ color: "#7852E6", fontSize: "30px" }}
                >
                  {user?.name}
                </Typography>
              }
              subheader={
                <Typography variant="subtitle1" sx>
                  {user?.responsibility}
                </Typography>
              }
            />
          </div>

          <CardContent>
            <List>
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-end",
                }}
              >
                <ListItem disablePadding>
                  <ListItemText
                    primary="Phone Number"
                    secondary={user?.mobileNumber}
                    sx={{ color: "#7852E6" }}
                  />
                </ListItem>

                <ListItem disablePadding>
                  <ListItemText
                    primary="Email"
                    secondary={user?.email}
                    sx={{ color: "#7852E6" }}
                  />
                </ListItem>

                <ListItem disablePadding>
                  <ListItemText
                    primary="Role"
                    secondary={user?.role}
                    sx={{ color: "#7852E6" }}
                  />
                </ListItem>
              </div>

              {/* Add more user details as needed */}
            </List>
          </CardContent>
        </Card>
      </ModalContent>
    </CustomModal>
  );
};

const TableWithSearch = (props) => {
  const email = props.email;
  const [editedUser, setEditedUser] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const formData = useSelector((state) => state.form.data);
  // const [filteredData,setFilteredData]=useState(formData)
  const showData = formData;
  console.log("This is form data", formData);
  const [searchText, setSearchText] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };
  const handleButtonClick = (event) => {
    navigate("/userForm", { state: { email } });
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleMenuItemClick = () => {
    // Logic for handling the menu item click
    console.log("Menu item clicked!");
    setAnchorEl(null);
  };
  const handleAccountIconClick = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
    setEditedUser(null); // Reset the editedUser state to prevent editing
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    if (editedUser) {
      updateUser(editedUser);
      setEditedUser(null);
    }
  };

  const filteredData = formData.filter((item) =>
    item.email.toLowerCase().includes(searchText.toLowerCase())
  );

  const handleDelete = (user) => {
    setSelectedUser(user);

    setOpenDialog(true);
    console.log(selectedUser);
  };

  const handleConfirmDelete = async (user) => {
    console.log("for conifmr deteke", selectedUser);
    try {
      const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
      const response = await axios.delete(
        `http://localhost:3001/api/users/${selectedUser.email}`,
        {
          headers: {
            api_key: token,
            "Content-Type": "application/json",
            "ngrok-skip-browser-warning": true,
          },
        }
      );

      if (response.status === 200) {
        console.log("user delete response", response);
        dispatch(deleteUser(user.username));
        dispatch(fetchUsers());
      } else {
        // Handle error response
        console.error("Error deleting user:", response.statusText);
      }
    } catch (error) {
      // Handle network or other errors
      console.error("Error deleting user:", error.message);
    }
    setOpenDialog(false);
  };

  const handleCancelDelete = () => {
    // Close the confirmation dialog
    setOpenDialog(false);
  };

  const handleEdit = (user) => {
  console.log(user, " this is edited user");
    setEditedUser(user);
    setIsEditModalOpen(true);
  };

  return (
    <div>
      <Typography
        variant="h4"
        sx={{
          color: "#525252",
          fontWeight: 700,
        }}
      >
        User Management
      </Typography>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <TextField
          label="Search"
          value={searchText}
          onChange={handleSearchChange}
          margin="normal"
          size="small"
          sx={{
            width: "30vw",
          }}
        />
        <Button
          onClick={handleButtonClick}
          sx={{
            background: "#7F265B",
            color: "white",
          }}
        >
          USER +
        </Button>
      </div>
      <div
        style={{
          maxHeight: "62.5vh",
          overflow: "auto",
          border: "1px solid #ccc",
          borderRadius: "4px",
          boxShadow: "0 0 5px rgba(0, 0, 0, 0.1)",
        }}
      >
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell></TableCell>
                <TableCell>Email ID</TableCell>
                <TableCell>User</TableCell>
                <TableCell>Phone Number</TableCell>
                <TableCell>Responsibility</TableCell>
                <TableCell>Role</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {filteredData.map((item) => (
                <TableRow>
                  <TableCell>
                    <Avatar
                      alt="User Avatar"
                      src="/path/to/default-avatar.jpg"
                      sx={{ marginRight: 1 }}
                    />
                  </TableCell>
                  <TableCell>{item.email}</TableCell>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.mobileNumber}</TableCell>
                  <TableCell>{item.responsibility}</TableCell>
                  <TableCell>{item.role}</TableCell>
                  <TableCell>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <IconButton onClick={() => handleAccountIconClick(item)}>
                        <AccountCircleIcon />
                      </IconButton>
                      <IconButton onClick={() => handleEdit(item)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDelete(item)}>
                        <DeleteIcon />
                      </IconButton>
                      <Dialog open={openDialog} onClose={handleCancelDelete}>
                        <DialogTitle>Confirm Delete</DialogTitle>
                        <DialogContent>
                          <p>Are you sure you want to delete?</p>
                        </DialogContent>
                        <DialogActions>
                          <Button onClick={handleCancelDelete}>Cancel</Button>
                          <Button onClick={handleConfirmDelete}>Delete</Button>
                        </DialogActions>
                      </Dialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      <UserModal
        user={selectedUser}
        open={isModalOpen}
        onClose={handleCloseModal}
      />
      <EditedUserModal
        user={editedUser}
        open={isEditModalOpen}
        onClose={handleCloseModal}
        setIsEditModalOpen={setIsEditModalOpen}
      />
    </div>
  );
};

const mapStateToProps = (state) => ({
  data: state.form.data, // Assuming you have a reducer named 'form' that contains the 'data' array
});

export default connect(mapStateToProps, { updateUser })(TableWithSearch);
