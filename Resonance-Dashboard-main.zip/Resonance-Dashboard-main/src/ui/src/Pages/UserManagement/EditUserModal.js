import React from "react";
import { useState } from "react";
import { connect } from "react-redux";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  DialogActions,
  DialogContent,
  DialogContentText,
  TextField,
  Button,
  InputLabel,
  Select,
  Menu,
  MenuItem,
  IconButton,
  Typography,
  Modal,
  FormControl,
  DialogTitle,
} from "@mui/material";

import { useDispatch } from "react-redux";
import { styled } from "@mui/system";
import { updateUser } from "../reducers/formReducer";
import { useEffect } from "react";
import axios from "axios";
import CloseIcon from "@mui/icons-material/Close";

const CustomModal = styled(Modal)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));
const ModalContent = styled("div")(({ theme }) => ({
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "400px",
  backgroundColor: "#F0F0FF",
  boxShadow: "0 2px 10px rgba(0, 0, 0, 0.2)",
  outline: "none",
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(4),
}));

export const EditedUserModal = ({
  user,
  open,
  onClose,
  setIsEditModalOpen,
}) => {
  console.log(onClose)
  console.log(setIsEditModalOpen)
  const dispatch = useDispatch();
  console.log(user);
  const [name, setName] = useState(null);
  console.log(name);
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);
  const [role, setRole] = useState(null);
  const [responsibility, setResponsibility] = useState(null);
  const [mobileNumber, setMobileNumber] = useState(null);
  const [selectedManager, setSelectedManager] = useState([]);
  const [selectedReportees, setSelectedReportees] = useState([]);
  const [address, setAddress] = useState(null);
  const [next, setNext] = useState(false);
  const [operatorReportees, setOperatorReportees] = useState([]);
  const [executiveReportees, setExecutiveReportees] = useState([]);
  const [supervisorReportees, setSupervisorReportees] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
        const headers = {
          api_key: token,
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": true,
        };

        const operatorResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Operator",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        const executiveResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Executive",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        const supervisorResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Supervisor",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        console.log(operatorResponse.data);
        console.log(executiveResponse.data);
        console.log(supervisorResponse.data);

        // Update the corresponding state with the reportees from each API response
        setOperatorReportees(operatorResponse.data);
        setExecutiveReportees(executiveResponse.data);
        setSupervisorReportees(supervisorResponse.data);

        console.log(operatorReportees);
      } catch (error) {
        // Handle error if necessary
        console.log(error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    setName(user?.name);
    setEmail(user?.email);
    setMobileNumber(user?.mobileNumber);
    setRole(user?.role);
    setResponsibility(user?.responsibility);
    setAddress(user?.address);
  }, [user]);

  const handleNameChange = (event) => {
    console.log(event);

    setName(event.target.value);
  };

  const handleEmailChange = (event) => {
    console.log(event);

    setEmail(event.target.value);
  };

  const handleMobileChange = (event) => {
    console.log(event);

    setMobileNumber(event.target.value);
  };

  const handleRoleChange = (event) => {
    console.log(event);

    setRole(event.target.value);
  };
  const handleResponsibilityChange = (event) => {
    console.log(event);

    setResponsibility(event.target.value);
  };

  const handleNext = () => {
    setNext(!next);
  };

  const handleSave = async () => {
    const updatedUser = {
      ...user,
      name: name,
      role: role,
      responsibility: responsibility,
      countryCode: "91",
      mobileNumber: mobileNumber,
      email: email,
      designation: "Default",
      img: null,
      address: address,
    };

    const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
    const headers = {
      api_key: token,
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": true,
    };

    try {
      const response = await axios.put(
        `http://localhost:3001/api/users/${user.email}`,
        updatedUser,
        {
          headers: headers,
        }
      );
      console.log(response);

      if (response.status === 200) {
        // User updated successfully
        dispatch(updateUser(updatedUser));
        console.log("Update successfull");
        setIsEditModalOpen(false);
      } else {
        // Handle error response
        console.error("Error updating user:", response.statusText);
      }
    } catch (error) {
      // Handle network or other errors
      console.error("Error updating user:", error.message);
    }
  };

  return (
    <CustomModal open={open} onClose={onClose}>
      <ModalContent>
        <Typography variant="h5" gutterBottom>
          Edit User Details
        </Typography>
        <IconButton
          sx={{
            position: "absolute",
            top: "25px",
            right: "20px",
          }}
          edge="end"
          color="inherit"
          onClick={onClose}
          aria-label="close"
        >
          <CloseIcon />
        </IconButton>
        <>
          {next === true && responsibility === "Operator" && (
            <>
              <FormControl fullWidth>
                <DialogTitle
                  sx={{
                    color: "#7F265B",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  Operator
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <FormControl fullWidth margin="normal">
                    <InputLabel htmlFor="manager-select">Manager</InputLabel>
                    <Select
                      id="manager-select"
                      value={selectedManager}
                      onChange={(e) => setSelectedManager(e.target.value)}
                      fullWidth
                    >
                      {supervisorReportees.map((operator) => (
                        <MenuItem key={operator.email} value={operator}>
                          {operator.email}
                        </MenuItem>
                      ))}
                      {/* Add more managers as required */}
                    </Select>
                  </FormControl>
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleSave(user)} sx={{ color: "#7F265B" }}>
                    Submit
                  </Button>
                </DialogActions>
              </FormControl>
            </>
          )}
          {next === false && (
            <>
              <FormControl fullWidth>
                <TextField
                  key="email"
                  label="Email"
                  value={email}
                  onChange={handleEmailChange}
                  margin="normal"
                />
                <TextField
                  key="mobileNumber"
                  label="Mobile Number"
                  value={mobileNumber}
                  onChange={handleMobileChange}
                  margin="normal"
                />
                <TextField
                  select
                  fullWidth
                  value={role}
                  margin="normal"
                  size="small"
                  label="Role"
                  onChange={(e) => handleRoleChange(e)}
                >
                  <MenuItem value="Admin">Admin</MenuItem>
                  <MenuItem value="User">User</MenuItem>
                </TextField>
                <TextField
                  select
                  fullWidth
                  value={responsibility}
                  margin="normal"
                  size="small"
                  label="Responsibility"
                  onChange={(e) => handleResponsibilityChange(e)}
                >
                  <MenuItem value="Executive">Executive</MenuItem>
                  <MenuItem value="Supervisor">Supervisor</MenuItem>
                  <MenuItem value="Operator">Operator</MenuItem>
                </TextField>
                {/* Add more user details as needed */}
              </FormControl>
              <Button
               variant="contained"
                onClick={() => {
                  handleNext()
                  
                }}
              >
                Next
              </Button>
            </>
          )}
        </>
      </ModalContent>
    </CustomModal>
  );
};
