import React from "react";
import {
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
} from "@mui/material";
import { useState } from "react";
// import { makeStyles } from '@mui/styles';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const theme = createTheme();

// const useStyles = makeStyles((theme) => ({
//   tableContainer: {
//     marginTop: theme.spacing(2),
//     boxShadow: theme.shadows[3],
//   },
//   tableHeaderCell: {
//     fontWeight: 'bold',
//     backgroundColor: theme.palette.primary.main,
//     color: theme.palette.common.white,
//   },
//   tableRow: {
//     '&:nth-of-type(even)': {
//       backgroundColor: theme.palette.action.hover,
//     },
//   },
// }));

export const SystemDefinitionContent = () => {

  const [tabValue, setTabValue] = useState(0);

//   const classes = useStyles();

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <ThemeProvider theme={theme}>
      <div>
        <Typography
          variant="h4"
          sx={{
            color: "#525252",
            fontWeight: 700,
          }}
        >
          System Definition
        </Typography>
        <div>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            textColor="secondary"
            indicatorColor="secondary"
            aria-label="Equipment Tabs"
          >
            <Tab label="Equipment Type" />
            <Tab label="Equipment" />
          </Tabs>

          {tabValue === 0 && (
            <div>
              {/* Equipment Type Content */}
              <TableContainer component={Paper} >
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell >Equipment Name</TableCell>
                      <TableCell >Number of Parameters</TableCell>
                      <TableCell >Number of virtual parameters</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell>Row 1, Cell 1</TableCell>
                      <TableCell>Row 1, Cell 2</TableCell>
                      <TableCell>Row 1, Cell 3</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Row 2, Cell 1</TableCell>
                      <TableCell>Row 2, Cell 2</TableCell>
                      <TableCell>Row 2, Cell 3</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                    {/* Add more rows as required */}
                  </TableBody>
                </Table>
              </TableContainer>
            </div>
          )}

          {tabValue === 1 && (
            <div>
            {/* Equipment Type Content */}
            <TableContainer component={Paper} >
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell >Equipment Name</TableCell>
                    <TableCell >Number of Parameters</TableCell>
                    <TableCell >Number of virtual parameters</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>Row 1, Cell 1</TableCell>
                    <TableCell>Row 1, Cell 2</TableCell>
                    <TableCell>Row 1, Cell 3</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Row 2, Cell 1</TableCell>
                    <TableCell>Row 2, Cell 2</TableCell>
                    <TableCell>Row 2, Cell 3</TableCell>
                  </TableRow>
                  {/* Add more rows as required */}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
          )}
        </div>

      </div>
    </ThemeProvider>
  );
};
