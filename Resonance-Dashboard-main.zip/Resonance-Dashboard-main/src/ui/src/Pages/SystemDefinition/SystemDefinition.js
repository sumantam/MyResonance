import * as React from "react";
// import Icon from "./Icon.png";
import "../css/scrollbar.css";
import { styled, useTheme } from "@mui/material/styles";

import { Button } from "@mui/material";
import Popover from "@mui/material/Popover";

import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";

import Avatar from "@mui/material/Avatar";

import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";

import { useNavigate } from "react-router-dom";

import TableWithSearch from "../UserManagement/UserManagementTable";

import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import SideBar from "../Layout/SideBar";
import { SystemDefinitionContent } from "./SystemDefinitionContent";
import { TopBar } from "../Layout/TopBar";

const drawerWidth = 250;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  background: "#5A57FF",
}));



const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  height: "100vh",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
    height: "100vh",
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
    height: "100vh",
  }),
}));

export default function SystemDefinition(props) {
  const location = useLocation();
  const email = location?.state?.email || location?.state?.navBaremail || "";

  const navigate = useNavigate();
  const theme = useTheme();
  const [openPopOver, setOpenPopOver] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [config, setConfig] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
 
  // const [isPopoverOpen, setPopoverOpen] = React.useState(false);
  const avatarRef = useRef(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenPopOver(true);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setOpenPopOver(false);

    // Reset the anchorEl to null to close the popover
  };


  const handleLogout = () => {
    console.log("clicked !");
  };
  const handleDrawerOpen = () => {
    theme.direction = "rtl";
    setOpen(true);
  };

  const handleDrawerClose = () => {
    theme.direction = "ltr";
    setOpen(false);
  };

  const navigateLogout = () => {
    navigate("/");
  };

  return (
    <Box className="custom-scrollbar" sx={{ display: "flex" }}>
      <CssBaseline />
      <TopBar></TopBar>
      <SideBar/>
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            padding: "30px",
          }}
        ></div>

        {/* Place the component here below */}
        <SystemDefinitionContent/>
      </Box>
    </Box>
  );
}



