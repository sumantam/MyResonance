import React, { useState, useCallback, useEffect } from "react";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import CloseIcon from "@mui/icons-material/Close";

import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import {
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Dialog,
  Chip,
  DialogTitle,
  DialogContentText,
  DialogContent,
  DialogActions,
  Typography,
  Grid,
  Paper,
  IconButton,
  FormHelperText,
  Input,
  Avatar,
} from "@mui/material";

import axios from "axios";
import { addUser } from "./reducers/formReducer";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useDropzone } from "react-dropzone";

const UserFormContent = (props) => {
  const navBaremail = props.email;
  const dispatch = useDispatch();
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [responsibility, setResponsibility] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [email, setEmail] = useState("");
  const [selectedImage, setSelectedImage] = useState(null);
  const [address, setAddress] = useState(null);
  const navigate = useNavigate();
  const [mobileNumberError, setMobileNumberError] = useState("");
  const [popUp, setPopUp] = useState(false);
  const [selectedManager, setSelectedManager] = useState([]);
  const [selectedReportees, setSelectedReportees] = useState([]);
  const [operatorReportees, setOperatorReportees] = useState([]);
  const [executiveReportees, setExecutiveReportees] = useState([]);
  const [supervisorReportees, setSupervisorReportees] = useState([]);
  const [clickButton, setClickButton] = useState(false);
  const auth = getAuth();

  const handlePopUpOpen = () => {
    setPopUp(true);
    setClickButton(true);
  };

  const handlePopUpClose = () => {
    setPopUp(false);
    setSelectedReportees([]);
    setSelectedManager([]);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
        const headers = {
          api_key: token,
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": true,
        };

        const operatorResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Operator",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        const executiveResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Executive",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        const supervisorResponse = await axios.get(
          "http://localhost:3001/api/users/responsibility/search?q=Supervisor",
          {
            headers: {
              api_key: token,
              "Content-Type": "application/json",
              "ngrok-skip-browser-warning": true,
            },
          }
        );
        console.log(operatorResponse.data);
        console.log(executiveResponse.data);
        console.log(supervisorResponse.data);

        // Update the corresponding state with the reportees from each API response
        setOperatorReportees(operatorResponse.data);
        setExecutiveReportees(executiveResponse.data);
        setSupervisorReportees(supervisorResponse.data);

        console.log(operatorReportees);
      } catch (error) {
        // Handle error if necessary
        console.log(error);
      }
    };

    fetchData();
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const relationData = {
      user: {
        email: email,
        name: name,
      },
      mgrList: Array.isArray(selectedManager)
        ? selectedManager.map((manager) => ({
            email: manager.email,
            name: manager.name,
          }))
        : [],
      reporteeList: selectedReportees.map((reportee) => ({
        email: reportee.email,
        name: reportee.name,
      })),
    };

    const newFormData = {
      name: name,
      role: role,
      responsibility: responsibility,
      countryCode: "91",
      mobileNumber: mobileNumber,
      email: email,
      designation: "Default",
      img: null,
      address: address,
    };

    // const relationData={
    //   email:email,
    //   manager: manager || "", // [{email,name}]
    //   reportees:reportees ||""
    // }

    try {
      const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
      const headers = {
        api_key: token,
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": true,
      };

      const response = await axios.post(
        "http://localhost:3001/api/users",
        newFormData,
        {
          headers: headers,
        }
      );
      if (response.status === 200) {
        const newUser = response.data; // Assuming the response contains the newly created user
        dispatch(addUser(newUser));

        // Clear the form fields
        setName("");
        setPassword("");
        setRole("");
        setResponsibility("");
        setMobileNumber("");
        setEmail("");
        setSelectedImage(null);
        setAddress("");
        setSelectedManager("");
        setSelectedReportees([]);

        // setTimeout(() => {
        //   navigate(-1);
        // }, 1000);
      } else {
        // Handle error response
        console.error("Error adding user:", response.statusText);
      }

      createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          // Signed in

          const user = userCredential.user;
          console.log(user);
          // ...
        })
        .catch((error) => {
          const errorCode = error.code;
          const errorMessage = error.message;
          console.log(errorMessage);
          // ..
        });

      const secondresponse = await axios.post(
        "http://localhost:3001/api/users/relation",
        relationData,
        {
          headers: headers,
        }
      );
      if (secondresponse.status === 200) {
        setTimeout(() => {
          navigate(-1);
        }, 1000);
      } else {
        // Handle error response
        console.error("Error sending relation Data : ", response.statusText);
      }
    } catch (error) {
      // Handle network or other errors
      console.error("Major Error: ", error.message);
    }
  };

  const handleDrop = useCallback((acceptedFiles) => {
    // Do something with the dropped files
    console.log(acceptedFiles);
  }, []);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    accept: "image/jpeg",
  });
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    // Do something with the selected file
    console.log(file);
  };

  const validateEmail = (email) => {
    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailChange = (e) => {
    const emailValue = e.target.value;
    setEmail(emailValue);
  };
  const handleMobileNumberChange = (e) => {
    const inputValue = e.target.value;
    setMobileNumber(inputValue);

    // Validate phone number format
    const isValidMobileNumber = /^\d{10}$/.test(inputValue);
    if (isValidMobileNumber) {
      setMobileNumberError("");
    } else {
      setMobileNumberError("Please enter a valid 10-digit phone number.");
    }
  };

  const navigateBack = () => {
    navigate("/usermanagement", { state: { navBaremail } });
  };
  return (
    <Grid container spacing={2}>
      <Typography
        variant="h4"
        sx={{
          color: "#525252",
          fontWeight: 700,
        }}
      >
        User Management
      </Typography>
      <Grid item xs={6}>
        <div
          style={{
            display: "flex",
            flexDirection: "column", // Set flexDirection to column
            alignItems: "center",
            textAlign: "center",
          }}
        >
          <Avatar
            alt="User"
            src="https://example.com/user-profile-image.jpg"
            sx={{
              width: 100,
              height: 100,
              marginBottom: 2,
              alignSelf: "center",
              border: isDragActive ? "2px dashed primary.main" : "none",
              cursor: "pointer",
            }}
            {...getRootProps()}
          >
            <input {...getInputProps()} />
            {isDragActive && (
              <CloudUploadIcon
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  color: "primary.main",
                  fontSize: 40,
                }}
              />
            )}
          </Avatar>
          <Typography
            variant="h4"
            align="center"
            sx={{ color: "#525252", fontWeight: "bold", fontSize: "24px" }}
          >
            {isDragActive ? "Drop the JPG file here" : "UPLOAD IMAGE"}
          </Typography>
          <Button
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              marginTop: "5rem",
              marginRight: "1rem",
              backgroundColor: "#7F265B",
              color: "white",
            }}
            onClick={navigateBack}
          >
            <ArrowBackIcon
              sx={{
                marginRight: "0.25vw",
              }}
            ></ArrowBackIcon>
            Back
          </Button>
        </div>
      </Grid>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          width: "80vw",
          marginLeft: "7vw",
        }}
      >
        <form
          onSubmit={handleFormSubmit}
          style={{
            backgroundColor: "#ffffff",
            width: "92.5vw",
          }}
        >
          <Paper sx={{ padding: 2, backgroundColor: "#ffffff" }}>
            <div style={{ display: "flex", gap: "1rem" }}>
              <TextField
                size="small"
                label="Email"
                value={email}
                onChange={handleEmailChange}
                margin="normal"
                fullWidth
                error={email && !validateEmail(email)}
                helperText={
                  email && !validateEmail(email) ? "Invalid email format" : ""
                }
              />

              <TextField
                label="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                margin="normal"
                type="password"
                size="small"
                fullWidth
              />
            </div>
            <div style={{ display: "flex", gap: "1rem" }}>
              <TextField
                label="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                margin="normal"
                size="small"
                fullWidth
              />

              {/* <FormControl fullWidth margin="normal" size="small" label="Role">
                <InputLabel>Role</InputLabel>
                <Select value={role} onChange={(e) => setRole(e.target.value)}>
                  <MenuItem value="Admin">Admin</MenuItem>
                  <MenuItem value="User">User</MenuItem>
                </Select>
              </FormControl> */}

              <TextField
                select
                fullWidth
                margin="normal"
                size="small"
                label="Role"
                onChange={(e) => setRole(e.target.value)}
              >
                <MenuItem value="Admin">Admin</MenuItem>
                <MenuItem value="User">User</MenuItem>
              </TextField>
            </div>

            <div style={{ display: "flex", gap: "1rem" }}>
              {/* <FormControl fullWidth margin="normal" size="small">
                <InputLabel>Responsibility</InputLabel>
                <Select
                  value={responsibility}
                  onChange={(e) => {
                    setResponsibility(e.target.value);
                  }}
                  required
                >
                  <MenuItem value="Executive">Executive</MenuItem>
                  <MenuItem value="Supervisor">Supervisor</MenuItem>
                  <MenuItem value="Operator">Operator</MenuItem>
                </Select>
                <FormHelperText>This field is required</FormHelperText>
              </FormControl> */}

              <TextField
                select
                fullWidth
                margin="normal"
                size="small"
                label="Responsibility"
                onChange={(e) => setResponsibility(e.target.value)}
              >
                <MenuItem value="Executive">Executive</MenuItem>
                <MenuItem value="Supervisor">Supervisor</MenuItem>
                <MenuItem value="Operator">Operator</MenuItem>
              </TextField>

              <TextField
                size="small"
                label="Phone Number"
                value={mobileNumber}
                onChange={handleMobileNumberChange}
                margin="normal"
                fullWidth
                error={!!mobileNumberError}
                helperText={mobileNumberError}
              />
            </div>
            <TextField
              size="small"
              label="Location"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value);
              }}
              margin="normal"
              fullWidth
            />
            <Box display="flex" justifyContent="center" marginTop="1rem">
              <Button
                type="button"
                variant="contained"
                sx={{
                  background: "#7F265B",
                  width:"10vw"
                 
                }}
                onClick={handlePopUpOpen}
              >
                Next
              </Button>
            </Box>
            {/* {responsibility === "" && (
              <Dialog open={popUp} onClose={handlePopUpClose}>
                <DialogTitle
                  sx={{
                    color: "red",
                  }}
                >
                  Please fill in the responsibility before proceeding.
                </DialogTitle>
              </Dialog>
            )} */}
            {responsibility === "Operator" && (
              // <Dialog open={popUp} onClose={handlePopUpClose}>
              //   <DialogTitle
              //     sx={{
              //       color: "#7F265B",
              //     }}
              //   >
              //     Operator
              //   </DialogTitle>
              //   <DialogContent>
              //     <DialogContentText>
              //       Fill in the following details
              //     </DialogContentText>
              //     <FormControl fullWidth margin="normal">
              //       <InputLabel htmlFor="manager-select">Manager</InputLabel>
              //       <Select
              //         id="manager-select"
              //         value={selectedManager}
              //         onChange={(e) => setSelectedManager(e.target.value)}
              //         fullWidth
              //       >
              //         {supervisorReportees.map((operator) => (
              //           <MenuItem key={operator.email} value={operator}>
              //             {operator.email}
              //           </MenuItem>
              //         ))}
              //         {/* Add more managers as required */}
              //       </Select>
              //     </FormControl>
              //   </DialogContent>
              //   <DialogActions>
              //     <Button onClick={handlePopUpClose} sx={{ color: "#7F265B" }}>
              //       Cancel
              //     </Button>
              //     <Button onClick={handleFormSubmit} sx={{ color: "#7F265B" }}>
              //       Submit
              //     </Button>
              //   </DialogActions>
              // </Dialog>

              <Dialog open={popUp} onClose={handlePopUpClose} fullWidth>
                <DialogTitle
                  sx={{
                    color: "#7F265B",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  Operator
                  <IconButton
                    edge="end"
                    color="inherit"
                    onClick={handlePopUpClose}
                    aria-label="close"
                  >
                    <CloseIcon />
                  </IconButton>
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <FormControl fullWidth margin="normal">
                    <InputLabel htmlFor="manager-select">Manager</InputLabel>
                    <Select
                      id="manager-select"
                      value={selectedManager}
                      onChange={(e) => setSelectedManager(e.target.value)}
                      fullWidth
                    >
                      {supervisorReportees.map((operator) => (
                        <MenuItem key={operator.email} value={operator}>
                          {operator.email}
                        </MenuItem>
                      ))}
                      {/* Add more managers as required */}
                    </Select>
                  </FormControl>
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleFormSubmit} sx={{ color: "#7F265B" }}>
                    Submit
                  </Button>
                </DialogActions>
              </Dialog>
            )}
            {responsibility === "Supervisor" && (
              <Dialog open={popUp} onClose={handlePopUpClose} fullWidth>
                <DialogTitle
                  sx={{
                    color: "#7F265B",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  Supervisor
                  <IconButton
                    edge="end"
                    color="inherit"
                    onClick={handlePopUpClose}
                    aria-label="close"
                  >
                    <CloseIcon />
                  </IconButton>
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <FormControl fullWidth margin="normal">
                    <InputLabel htmlFor="manager-select">Manager</InputLabel>
                    <Select
                      id="manager-select"
                      value={selectedManager}
                      onChange={(e) => setSelectedManager(e.target.value)}
                      fullWidth
                    >
                      {executiveReportees.map((operator) => (
                        <MenuItem key={operator.email} value={operator}>
                          {operator.email}
                        </MenuItem>
                      ))}
                      {/* Add more managers as required */}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth margin="normal">
                    <InputLabel htmlFor="reportees-select">
                      Reportees
                    </InputLabel>
                    <Select
                      id="reportees-select"
                      multiple
                      value={selectedReportees}
                      onChange={(e) => setSelectedReportees(e.target.value)}
                      renderValue={(selected) => (
                        <div>
                          {selected.map((value) => (
                            <Chip key={value.name} label={value.name} />
                          ))}
                        </div>
                      )}
                      fullWidth
                    >
                      {operatorReportees.map((operator) => (
                        <MenuItem key={operator.email} value={operator}>
                          {operator.email}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleFormSubmit} sx={{ color: "#7F265B" }}>
                    Submit
                  </Button>
                </DialogActions>
              </Dialog>
            )}
            {responsibility === "Executive" && (
              <Dialog open={popUp} onClose={handlePopUpClose} fullWidth>
                <DialogTitle
                  sx={{
                    color: "#7F265B",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  Executive
                  <IconButton
                    edge="end"
                    color="inherit"
                    onClick={handlePopUpClose}
                    aria-label="close"
                  >
                    <CloseIcon />
                  </IconButton>
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>

                  <FormControl fullWidth margin="normal">
                    <InputLabel htmlFor="reportees-select">
                      Supervisors
                    </InputLabel>
                    <Select
                      id="reportees-select"
                      multiple
                      value={selectedManager}
                      onChange={(e) => setSelectedManager(e.target.value)}
                      renderValue={(selected) => (
                        <div>
                          {selected.map((value) => (
                            <Chip key={value} label={value} />
                          ))}
                        </div>
                      )}
                      fullWidth
                    >
                      {supervisorReportees.map((operator) => (
                        <MenuItem key={operator.email} value={operator.email}>
                          {operator.email}
                        </MenuItem>
                      ))}
                      {/* Add more reportees as required */}
                    </Select>
                  </FormControl>
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleFormSubmit} sx={{ color: "#7F265B" }}>
                    Submit
                  </Button>
                </DialogActions>
              </Dialog>
            )}
          </Paper>
        </form>
      </div>
    </Grid>
  );
};

export default UserFormContent;
