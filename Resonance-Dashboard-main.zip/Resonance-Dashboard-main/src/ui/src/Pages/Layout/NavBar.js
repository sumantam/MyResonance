

import React, { useState } from "react";

import Drawer from "@mui/material/Drawer";

import List from "@mui/material/List";

import ListItem from "@mui/material/ListItem";

import ListItemButton from "@mui/material/ListItemButton";

import ListItemIcon from "@mui/material/ListItemIcon";

import ListItemText from "@mui/material/ListItemText";

import IconButton from "@mui/material/IconButton";

import MuiDrawer from "@mui/material/Drawer";

import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";

import ChevronRightIcon from "@mui/icons-material/ChevronRight";

import DashboardIcon from "@mui/icons-material/Dashboard";

import TuneIcon from "@mui/icons-material/Tune";

import AnalyticsIcon from "@mui/icons-material/Analytics";

import HistoryIcon from "@mui/icons-material/History";

import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";

import SettingsIcon from "@mui/icons-material/Settings";

import EditNotificationsIcon from "@mui/icons-material/EditNotifications";

import NotificationsIcon from "@mui/icons-material/Notifications";

import SummarizeIcon from "@mui/icons-material/Summarize";

import MapIcon from "@mui/icons-material/Map";

import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

import { useNavigate } from "react-router-dom";

import Icon from "../Images/Icon.png";

import { styled, useTheme } from "@mui/material/styles";

import { Typography } from "@mui/material";




const Sidebar = () => {

  const [open, setOpen] = useState(false);

  const [config, setConfig] = useState(false);




  const toggleDrawer = () => {

    setOpen(!open);

  };




  const navigate = useNavigate();

  const theme = useTheme();




  const handleNavigateToSystemDefinition = () => {

    setConfig(false);

    navigate("/system-definitions");

  };




  const drawerWidth = 250;




  const openedMixin = (theme) => ({

    width: drawerWidth,

    transition: theme.transitions.create("width", {

      easing: theme.transitions.easing.sharp,

      duration: theme.transitions.duration.enteringScreen,

    }),

    overflowX: "hidden",

    overflowY: "hidden", // Hide vertical scrollbar

  });




  const closedMixin = (theme) => ({

    transition: theme.transitions.create("width", {

      easing: theme.transitions.easing.sharp,

      duration: theme.transitions.duration.leavingScreen,

    }),

    overflowX: "hidden",

    overflowY: "hidden", // Hide vertical scrollbar

    width: `calc(${theme.spacing(7)} + 1px)`,

    [theme.breakpoints.up("sm")]: {

      width: `calc(${theme.spacing(8)} + 1px)`,

    },

  });




  const DrawerHeader = styled("div")(({ theme }) => ({

    display: "flex",

    alignItems: "center",

    justifyContent: "space-between",

    padding: theme.spacing(0, 1),

    // necessary for content to be below app bar

    ...theme.mixins.toolbar,

    background: "#5A57FF",

    position: "relative",

    zIndex: theme.zIndex.drawer + 1,

  }));




  const CustomDrawer = styled(MuiDrawer, {

    shouldForwardProp: (prop) => prop !== "open",

  })(({ theme, open }) => ({

    width: drawerWidth,

    flexShrink: 0,

    whiteSpace: "nowrap",

    boxSizing: "border-box",

    height: "100vh",

    overflowY: "hidden", // Hide vertical scrollbar

    ...(open && {

      ...openedMixin(theme),

      "& .MuiDrawer-paper": openedMixin(theme),

      height: "100vh",

    }),

    ...(!open && {

      ...closedMixin(theme),

      "& .MuiDrawer-paper": closedMixin(theme),

      height: "100vh",

    }),

  }));




  const subItems = [

    { text: "User Management", onClick: () => {} },

    { text: "System Definition", onClick: handleNavigateToSystemDefinition },

    { text: "Notification Config", onClick: () => {} },

  ];




  return (

    <CustomDrawer

      variant="permanent"

      open={open}

      sx={{

        height: "100vh",

        display: "flex",

        flexDirection: "column",

      }}

    >

      <DrawerHeader>

        <IconButton

          onClick={toggleDrawer}

          sx={{

            position: "absolute",

            top: 0,

            right: 0,

            backgroundColor: "#FFFFFF",

          }}

        >

          {open || theme.direction === "rtl" ? (

            <ChevronRightIcon />

          ) : (

            <ChevronLeftIcon />

          )}

        </IconButton>

        <img

          src={Icon}

          alt="Company Icon"

          style={{

            width: 50,

          }}

        />

        <Typography variant="h4" sx={{ color: "#FFFFFF", fontWeight: 700 }}>

          Resonance

        </Typography>

      </DrawerHeader>




      <List

        sx={{

          background: "linear-gradient(#5A57FF, #B649B1)",

          height: "200vh",

        }}

      >

        {[

          ,

          "Dashboard",

          "Configuration",

          ...(config ? subItems.map((item) => item.text) : []),

          "Analytics",

          "History",

          "Notification",

          "Reports",

          "Maps",

        ].map((text, index) => {

          const isConfig = text === "Configuration";

          const isSystemDefinition = text === "System Definition";




          return (

            <ListItem key={text} disablePadding sx={{ display: "block" }}>

              <ListItemButton

                onClick={() => {

                  if (text === "Resonance") {

                    toggleDrawer();

                  } else if (isConfig) {

                    setConfig(!config);

                  } else if (isSystemDefinition) {

                    handleNavigateToSystemDefinition();

                  }

                }}

                sx={{

                  minHeight: 48,

                  justifyContent: open ? "flex-start" : "center",

                  px: 2.5,

                  py: 2.5,

                  color: "white",

                  fontWeight: 300,

                  "&:hover": {

                    backgroundColor: "rgba(255, 255, 255, 0.2)",

                  },

                  fontSize: 18,

                  display: "flex",

                  alignItems: "center",

                }}

              >

                <ListItemIcon

                  sx={{

                    minWidth: 0,

                    marginRight: open ? 3 : "auto",

                    justifyContent: "center",

                    color: "white",

                    fontSize: isConfig ? 14 : 18,

                  }}

                >

                  {text === "Resonance"}

                  {text === "Dashboard" && <DashboardIcon />}

                  {isConfig && <TuneIcon />}

                  {text === "Analytics" && <AnalyticsIcon />}

                  {text === "History" && <HistoryIcon />}

                  {text === "User Management" && <ManageAccountsIcon />}

                  {isSystemDefinition && <SettingsIcon />}

                  {text === "Notification Config" && <EditNotificationsIcon />}

                  {text === "Notification" && <NotificationsIcon />}

                  {text === "Reports" && <SummarizeIcon />}

                  {text === "Maps" && <MapIcon />}

                </ListItemIcon>

                <ListItemText

                  primary={text}

                  sx={{

                    opacity: open ? 1 : 0,

                    marginLeft: 0.5,

                    fontSize: isConfig ? 14 : 18,

                  }}

                />

                {isConfig && (

                  <KeyboardArrowDownIcon

                    sx={{

                      color: "white",

                      position: "absolute",

                      right: 20,

                      transform: config ? "rotate(180deg)" : "rotate(0deg)",

                      transition: "transform 0.3s",

                    }}

                  />

                )}

              </ListItemButton>

            </ListItem>

          );

        })}

      </List>

    </CustomDrawer>

  );

};




export default Sidebar;


