
import * as React from "react";
import Icon from '../Images/Icon.png'
import "../css/scrollbar.css"
import { styled, useTheme } from "@mui/material/styles";
import MuiDrawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import DashboardIcon from "@mui/icons-material/Dashboard";
import SettingsIcon from "@mui/icons-material/Settings";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import TuneIcon from "@mui/icons-material/Tune";
import EditNotificationsIcon from "@mui/icons-material/EditNotifications";
import HistoryIcon from "@mui/icons-material/History";
import NotificationsIcon from "@mui/icons-material/Notifications";
import SummarizeIcon from "@mui/icons-material/Summarize";
import MapIcon from "@mui/icons-material/Map";
import AnalyticsIcon from "@mui/icons-material/Analytics";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { useNavigate } from "react-router-dom";


const drawerWidth = 250;

const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: "hidden",
  });
  
  const closedMixin = (theme) => ({
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up("sm")]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
    },
  });
  
  const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    background: "#5A57FF",
  }));

  const Drawer = styled(MuiDrawer, {
    shouldForwardProp: (prop) => prop !== "open",
  })(({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
    boxSizing: "border-box",
    height: "100vh",
    ...(open && {
      ...openedMixin(theme),
      "& .MuiDrawer-paper": openedMixin(theme),
      height: "100vh",
    }),
    ...(!open && {
      ...closedMixin(theme),
      "& .MuiDrawer-paper": closedMixin(theme),
      height: "100vh",
    }),
  }));

  export default function SideBar(){
    const navigate = useNavigate();
    const theme = useTheme();
    const [config, setConfig] = React.useState(false);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open, setOpen] = React.useState(false);
  
    const openPop = Boolean(anchorEl);


    const handleDrawerOpen = () => {
        theme.direction = "rtl";
        setOpen(true);
      };
    
      const handleDrawerClose = () => {
        theme.direction = "ltr";
        setOpen(false);
      };

      const navigateLogout = () => {
        navigate("/");
      };

    return(
        <Drawer
        variant="permanent"
        open={open}
        sx={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <DrawerHeader>
          <img
            src={Icon}
            alt="Company Icon"
            style={{
              width: "4vw",
              height: "7vh",
            }}
          />
          {theme.direction === "ltr" ? (
            <ChevronRightIcon
              onClick={() => {
                open ? handleDrawerClose() : handleDrawerOpen();
              }}
              sx={{
                color: "white",
              }}
            />
          ) : (
            <ChevronLeftIcon
              onClick={() => {
                open ? handleDrawerClose() : handleDrawerOpen();
              }}
              sx={{
                color: "white",
              }}
            />
          )}

          {/* or */}
          {/* <IconButton> */}
          {/* <CompanyIcon />
    </IconButton> */}
        </DrawerHeader>
        <List
          sx={{
            background: "linear-gradient(#5A57FF, #B649B1)",
            height: "200vh",
          }}
        >
          {/* <IconButton onClick={handleDrawerClose}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton> */}

          {[
            "Dashboard",
            "Configuration",
            ...(config
              ? [
                  "User Management",
                  "System Definition",
                  "Notification Config",
                  "System Level Parameters",
                ]
              : []),
            "Analytics",
            "History",
            "Notification",
            "Reports",
            "Maps",
          ].map((text, index) => (
            <ListItem key={text} disablePadding sx={{ display: "block" }}>
              <ListItemButton
                onClick={() => {
                   if (text === "Configuration") {
                    setConfig(!config);
                    console.log(!config);
                  }
                    else if(text==="System Definition"){
                      navigate("/system-definition")
                    }
                    else if(text==="User Management"){
                      navigate("/userManagement")
                    }
                }}
                sx={{
                  minHeight: 48,
                  justifyContent: open ? "flex-start" : "center",
                  px: 2.5,
                  py: 2.5,
                  color: "white",
                  fontWeight: 300,
                  "&:hover": {
                    backgroundColor: "rgba(255, 255, 255, 0.2)",
                  },
                  fontSize: 18,
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    marginRight: open ? 1 : "auto",

                    justifyContent: "center",
                    color: "white",
                    marginLeft:
                      text === "User Management" ||
                      text === "System Definition" ||
                      text === "Notification Config" ||
                      text === "System Level Parameters"
                        ? 3
                        : 0,
                    // fontSize: text === "User Management" || text === "System Definition" || text === "Notification Config"? 10:18,
                  }}
                >
                  {text === "Resonance" &&
                    (theme.direction === "ltr" ? (
                      <ChevronRightIcon />
                    ) : (
                      <ChevronLeftIcon />
                    ))}
                  {text === "Dashboard" && <DashboardIcon />}
                  {text === "Configuration" && <TuneIcon />}
                  {text === "Analytics" && <AnalyticsIcon />}
                  {text === "History" && <HistoryIcon />}
                  {text === "User Management" && (
                    <ManageAccountsIcon sx={{ fontSize: "1.2rem" }} />
                  )}
                  {text === "System Definition" && (
                    <SettingsIcon sx={{ fontSize: "1.2rem" }} />
                  )}
                  {text === "Notification Config" && (
                    <EditNotificationsIcon sx={{ fontSize: "1.2rem" }} />
                  )}
                  {text === "System Level Parameters" && (
                    <SettingsIcon sx={{ fontSize: "1.2rem" }} />
                  )}
                  {text === "Notification" && <NotificationsIcon />}
                  {text === "Reports" && <SummarizeIcon />}
                  {text === "Maps" && <MapIcon />}
                </ListItemIcon>
                <ListItemText
                  primary={
                    <Typography
                      variant="body1"
                      sx={{
                        fontSize:
                          text === "User Management" ||
                          text === "System Definition" ||
                          text === "Notification Config" ||
                          text === "System Level Parameters"
                            ? "0.75rem"
                            : "1rem", // Adjust the font size as needed
                        opacity: open ? 1 : 0,
                        marginLeft:
                          text === "User Management" ||
                          text === "System Definition" ||
                          text === "Notification Config" ||
                          text === "System Level Parameters"
                            ? 3
                            : 0.5,
                      }}
                    >
                      {text}
                    </Typography>
                  }
                  sx={{ opacity: open ? 1 : 0, marginLeft: 0.5 }}
                />
                {text === "Configuration" && config && <KeyboardArrowUpIcon />}
                {text === "Configuration" && !config && (
                  <KeyboardArrowDownIcon />
                )}
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>
    );
  }
  
