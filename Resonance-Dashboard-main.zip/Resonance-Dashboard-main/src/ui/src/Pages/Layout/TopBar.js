import * as React from "react";
import Icon from "../Images/Icon.png";
import "../css/scrollbar.css";
import { styled, useTheme } from "@mui/material/styles";

import { Button } from "@mui/material";
import Popover from "@mui/material/Popover";

import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";

import Avatar from "@mui/material/Avatar";

import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";

import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

import TableWithSearch from "../UserManagement/UserManagementTable";

import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import SideBar from "./SideBar";
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import { initializeApp } from "firebase/app";

import { getAuth } from "firebase/auth";

// Initialize Firebase
const firebaseConfig = {

  apiKey: "AIzaSyD-eTrK5x8bYDP87IK9O1mh1UZXSJ1-0XA",

  authDomain: "instance-fe5cc.firebaseapp.com",

  projectId: "instance-fe5cc",

  storageBucket: "instance-fe5cc.appspot.com",

  messagingSenderId: "300705379955",

  appId: "1:300705379955:web:823c9e4ac6f5f9028b5c06",

  measurementId: "G-ZEPY32HEVY",

};

firebase.initializeApp(firebaseConfig);


const drawerWidth = 250;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer - 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

export const TopBar = (props) => {
  const email = useSelector((state) => state.login.email);
  // const email = location?.state?.email || location?.state?.navBaremail || props.email  || "";

  const navigate = useNavigate();
  const theme = useTheme();
  const [openPopOver, setOpenPopOver] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [config, setConfig] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  // const [isPopoverOpen, setPopoverOpen] = React.useState(false);
  const avatarRef = useRef(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenPopOver(true);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setOpenPopOver(false);

    // Reset the anchorEl to null to close the popover
  };

  const handleAvatarClick = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenPopOver(true);
  };

  const handleLogout = () => {
    firebase.auth().signOut()
      .then(() => {
        // Logout successful
        console.log("User logged out successfully");
        navigate('/');
        // Perform additional actions or redirect the user to the login page
      })
      .catch((error) => {
        // An error occurred during logout
        console.error("Error logging out:", error);
      });
  };
  
  const handleDrawerOpen = () => {
    theme.direction = "rtl";
    setOpen(true);
  };

  const handleDrawerClose = () => {
    theme.direction = "ltr";
    setOpen(false);
  };

  const navigateLogout = () => {
    navigate("/");
  };

  return (
    <AppBar
      position="absolute"
      open={open}
      sx={{
        background: "#9e4dc6",
      }}
    >
      <Toolbar>
        <div
          style={{
            position: "fixed",
            right: "1rem",
            display: "flex",
            marginLeft: "80vw",
            alignItems: "center",
          }}
        >
          <Typography variant="p2" component="div" sx={{ marginRight: "1vw" }}>
            {email}
          </Typography>
          <Button onClick={handleAvatarClick}>
            <Avatar
              alt="User Avatar"
              src="/path/to/default-avatar.jpg"
              sx={{ marginRight: 1 }}
              aria-owns={open ? "mouse-over-popover" : undefined}
              aria-haspopup="true"
              ref={avatarRef}
            />
          </Button>

          <Popover
            open={openPopOver}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "center",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "center",
            }}
            // disableRestoreFocus
            onClose={() => setOpenPopOver(false)}
            id="mouse-over-popover"
            // sx={{
            //   pointerEvents: "none",
            // }}
          >
            <Paper
              elevation={3}
              sx={{
                minWidth: 200,
                padding: 2,
                backgroundColor: "#F4F5F7", // Custom background color
                textAlign: "center", // Center align the content
              }}
            >
              <Box sx={{ marginBottom: 3 }}>
                <Typography
                  variant="body1"
                  sx={{
                    fontWeight: "bold",
                  }}
                >
                  {email}
                </Typography>
              </Box>
              <Button
                variant="contained"
                onClick={handleLogout}
                sx={{
                  backgroundColor: "#f4f5f7", // Custom button color
                  color: "red", // Custom text color
                }}
              >
                Log out
              </Button>
            </Paper>
          </Popover>
          {/* Dropdown Menu */}
        </div>
      </Toolbar>
    </AppBar>
  );
};
