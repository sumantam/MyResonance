import { initializeApp } from "firebase/app";

import { getAuth } from "firebase/auth";

const firebaseConfig = {

  apiKey: "AIzaSyD-eTrK5x8bYDP87IK9O1mh1UZXSJ1-0XA",

  authDomain: "instance-fe5cc.firebaseapp.com",

  projectId: "instance-fe5cc",

  storageBucket: "instance-fe5cc.appspot.com",

  messagingSenderId: "300705379955",

  appId: "1:300705379955:web:823c9e4ac6f5f9028b5c06",

  measurementId: "G-ZEPY32HEVY",

};




// Initialize Firebase

const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service

const auth = getAuth(app);