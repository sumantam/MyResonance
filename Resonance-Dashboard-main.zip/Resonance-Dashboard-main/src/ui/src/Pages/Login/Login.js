// import * as React from "react";
// import Button from "@mui/material/Button";
// import Avatar from "@mui/material/Avatar";

// import CssBaseline from "@mui/material/CssBaseline";
// import TextField from "@mui/material/TextField";
// import FormControlLabel from "@mui/material/FormControlLabel";
// import Checkbox from "@mui/material/Checkbox";
// import Link from "@mui/material/Link";
// import Paper from "@mui/material/Paper";
// import Box from "@mui/material/Box";
// import Grid from "@mui/material/Grid";
// import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
// import Typography from "@mui/material/Typography";
// import Logo from "./resonance.png";
// import { useNavigate } from 'react-router-dom';
// import { createTheme, ThemeProvider } from "@mui/material/styles";

// export default function Login() {
//     const [invalidCredentials, setInvalidCredentials] = React.useState(false);
//   const handleSubmit = (event) => {
//     event.preventDefault();
//     const data = new FormData(event.currentTarget);
//     const email = data.get("email");
//     const password = data.get("password");

//     if (email === "admin" && password === "admin") {
//       handleLogin(email);
//     } else {
//       // Display error message
//       setInvalidCredentials(true);
//     }
//   };
//   const navigate = useNavigate();
//   const handleLogin = (email) => {
//     // Perform login logic

//     // Navigate to the dashboard page
//    navigate('/usermanagement', { state: { email } });
//   };
//   return (
//     <div>
//       {/* <Button variant="contained">Hello World</Button> */}
//       <Grid container component="main" sx={{ height: "100vh" }}>
//         <CssBaseline />
//         <Grid
//           item
//           xs={false}
//           sm={4}
//           md={8}
//           sx={{
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//             background: "linear-gradient(#5A57FF, #B649B1)",
//           }}
//         >
//           <img src={Logo} alt="React Logo" />
//         </Grid>
//         <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square>
//           <Box
//             sx={{
//               my: 8,
//               mx: 4,
//               display: "flex",
//               flexDirection: "column",
//               alignItems: "center",
//             }}
//           >
//             <Avatar sx={{ m: 1, bgcolor: "#7F265B" }}>
//               <LockOutlinedIcon />
//             </Avatar>
//             <Typography
//               component="h1"
//               variant="h5"
//               sx={{
//                 fontFamily: "'Roboto', sans-serif",
//                 fontWeight: "bold",
//                 fontSize: "24px",
//               }}
//             >
//               Log In To Your Account
//             </Typography>
//             <Typography
//               sx={{ fontFamily: "'Roboto', sans-serif", fontSize: "16px" }}
//             >
//               See what is going on with your machines
//             </Typography>

//             <Box
//               component="form"
//               noValidate
//               onSubmit={handleSubmit}
//               sx={{ mt: 1 }}
//             >
//               <TextField
//                 margin="normal"
//                 required
//                 fullWidth
//                 id="email"
//                 label="Email Address"
//                 name="email"
//                 autoComplete="email"
//                 autoFocus
//               />
//               <TextField
//                 margin="normal"
//                 required
//                 fullWidth
//                 name="password"
//                 label="Password"
//                 type="password"
//                 id="password"
//                 autoComplete="current-password"
//               />
//               {invalidCredentials && (
//         <div style={{ color: 'red', textAlign: 'center', marginTop: '10px' }}>
//           Invalid credentials
//         </div>
//       )}
//               <FormControlLabel
//                 control={<Checkbox value="remember" color="primary" />}
//                 label="Remember me"
//               />
//               <Grid item xs>
//                 <Link
//                   href="#"
//                   variant="body2"
//                   sx={{ color: "#7F265B", fontWeight: "bold" }}
//                 >
//                   Forgot password?
//                 </Link>
//               </Grid>
//               <Button
//                 type="submit"
//                 fullWidth
//                 //onClick={handleLogin}
//                 // variant="contained"
//                 sx={{
//                   backgroundColor: "#7F265B",
//                   color: "white",
//                   mt: 3,
//                   mb: 2,
//                   "&:hover": {
//                     backgroundColor: "purple",
//                   },
//                 }}
//               >
//                 Login
//               </Button>
//             </Box>
//           </Box>
//         </Grid>
//       </Grid>
//     </div>
//   );
// }

import * as React from "react";

import Button from "@mui/material/Button";

import Avatar from "@mui/material/Avatar";

import CssBaseline from "@mui/material/CssBaseline";

import TextField from "@mui/material/TextField";

import FormControlLabel from "@mui/material/FormControlLabel";

import Checkbox from "@mui/material/Checkbox";

import Link from "@mui/material/Link";

import Paper from "@mui/material/Paper";

import Box from "@mui/material/Box";

import Grid from "@mui/material/Grid";

import LockOutlinedIcon from "@mui/icons-material/LockOutlined";

import Typography from "@mui/material/Typography";

import Logo from "../Images/resonance.png";

import { useNavigate } from "react-router-dom";

import { createTheme, ThemeProvider } from "@mui/material/styles";

// Import the Firebase SDK

import { getAuth, signInWithEmailAndPassword } from "firebase/auth";

import { initializeApp } from "firebase/app";
import { setLoginDetails } from "../reducers/loginReducer";
import { useDispatch } from "react-redux";
import axios from "axios";

// Your web app's Firebase configuration

const firebaseConfig = {
  apiKey: "AIzaSyD-eTrK5x8bYDP87IK9O1mh1UZXSJ1-0XA",

  authDomain: "instance-fe5cc.firebaseapp.com",

  projectId: "instance-fe5cc",

  storageBucket: "instance-fe5cc.appspot.com",

  messagingSenderId: "300705379955",

  appId: "1:300705379955:web:823c9e4ac6f5f9028b5c06",

  measurementId: "G-ZEPY32HEVY",
};

// Initialize Firebase

const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service

const auth = getAuth(app);

export default function Login() {
  const [invalidCredentials, setInvalidCredentials] = React.useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleForgotPassword = () => {
    navigate("/forgotpassword");
  };

  const handleSubmit = async (event) => {
    console.log("clicked login")
    event.preventDefault();

    const data = new FormData(event.currentTarget);

    const email = data.get("email");

    const password = data.get("password");

    if (!email && !password) {
      setInvalidCredentials("Please enter your email and password");

      return;
    }

    if (!email) {
      setInvalidCredentials("Please enter your email");

      return;
    }

    if (!password) {
      setInvalidCredentials("Please enter your password");

      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,

        email,

        password
      );

      const user = userCredential.user;
      const token = "4870f96b-6590-43ef-bde5-ad20afdf3daa";
      const headers = {
        api_key: token,
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": true,
      };
      dispatch(setLoginDetails({ email: user.email }));

      const userDetailResponse= await axios.get(`http://localhost:3001/api/users/${user.email}`,{
        headers:headers
      })
      console.log(userDetailResponse);
      const userData=userDetailResponse.data;
        console.log(userData)
      if(userData.role==="Admin")
      {
        console.log("It is an admin")
        navigate("/userManagement", { state: { email: user.email } });

      }
      else if(userData.role==="User")
      {
        console.log("It is an User")
        navigate("/system-definition",{
          state:{
            email:user.email
          }
        })
      }
    } catch (error) {
      console.error("Error signing in with email and password", error);

      setInvalidCredentials("Invalid credentials");
    }
  };

  return (
    <div>
      {/* <Button variant="contained">Hello World</Button> */}

      <Grid container component="main" sx={{ height: "100vh" }}>
        <CssBaseline />

        <Grid
          item
          xs={false}
          sm={4}
          md={8}
          sx={{
            display: "flex",

            alignItems: "center",

            justifyContent: "center",

            background: "linear-gradient(#5A57FF, #B649B1)",
          }}
        >
          <img src={Logo} alt="React Logo" />
        </Grid>

        <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square>
          <Box
            sx={{
              my: 8,

              mx: 4,

              display: "flex",

              flexDirection: "column",

              alignItems: "center",
            }}
          >
            <Avatar sx={{ m: 1, bgcolor: "#7F265B" }}>
              <LockOutlinedIcon />
            </Avatar>

            <Typography
              component="h1"
              variant="h5"
              sx={{
                fontFamily: "'Roboto', sans-serif",

                fontWeight: "bold",

                fontSize: "24px",
              }}
            >
              Log In To Your Account
            </Typography>

            <Typography
              sx={{ fontFamily: "'Roboto', sans-serif", fontSize: "16px" }}
            >
              See what is going on with your machines
            </Typography>

            <Box
              component="form"
              noValidate
              onSubmit={handleSubmit}
              sx={{ mt: 1 }}
            >
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoFocus
                type="email"
              />

              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
              />

              {invalidCredentials && (
                <div
                  style={{
                    backgroundColor: "pink",

                    textAlign: "center",

                    marginTop: "10px",

                    padding: "10px",

                    color: "white",
                  }}
                >
                  {invalidCredentials}
                </div>
              )}

              {/* <FormControlLabel
                control={<Checkbox value="remember" color="primary" />}
                label="Remember me"
              /> */}

              <Grid item xs>
                <Link
                  href="#"
                  variant="body2"
                  sx={{ color: "#7F265B", fontWeight: "bold" }}
                  onClick={handleForgotPassword}
                >
                  Forgot password?
                </Link>
              </Grid>

              <Box sx={{ textAlign: "center", width: "100%" }}>
                <Button
                  type="submit"
                  sx={{
                    backgroundColor: "#7F265B",
                    color: "white",
                    mt: 3,
                    mb: 2,
                    "&:hover": {
                      backgroundColor: "purple",
                    },
                    width: "10vw"
                  }}
                >
                  Login
                </Button>
              </Box>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </div>
  );
}
