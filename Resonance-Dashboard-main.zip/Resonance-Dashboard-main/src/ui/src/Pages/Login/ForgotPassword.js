import React, { useState } from "react";

import { getAuth, sendPasswordResetEmail } from "firebase/auth";

import TextField from "@mui/material/TextField";

import Button from "@mui/material/Button";

import Logo from "../Images/resonance.png";

import Box from "@mui/material/Box";

import Grid from "@mui/material/Grid";

import Paper from "@mui/material/Paper";

import CssBaseline from "@mui/material/CssBaseline";
import { useNavigate } from "react-router-dom";

// Inside your component

const auth = getAuth();

export default function ForgotPassword() {
  const [email, setEmail] = useState("");

  const [emailSent, setEmailSent] = useState(false);

  const [emailError, setEmailError] = useState(false);

  const navigate = useNavigate();

  const handleEmailChange = (event) => {
    setEmail(event.target.value);

    setEmailError(false);
  };

  const handleResetPassword = async () => {
    // Validate email format

    const emailRegex = /^\S+@\S+\.\S+$/;

    if (!emailRegex.test(email)) {
      setEmailError(true);

      return;
    }

    try {
      await sendPasswordResetEmail(auth, email);

      setEmailSent(true);
    } catch (error) {
      console.error("Error sending password reset email", error);

      // Handle error, display error message, etc.
    }
  };

  return (
    <div>
      <Grid container component="main" sx={{ height: "100vh" }}>
        <CssBaseline />

        <Grid
          item
          xs={false}
          sm={4}
          md={8}
          sx={{
            display: "flex",

            alignItems: "center",

            justifyContent: "center",

            background: "linear-gradient(#5A57FF, #B649B1)",
          }}
        >
          <img src={Logo} alt="React Logo" />
        </Grid>

        <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square>
          <Box
            sx={{
              my: 8,

              mx: 4,

              display: "flex",

              flexDirection: "column",

              alignItems: "center",
            }}
          >
            <h1>Forgot Password</h1>

            {!emailSent ? (
              <>
                <p>Please enter your email address to reset your password:</p>

                <TextField
                  label="Email"
                  value={email}
                  onChange={handleEmailChange}
                  error={emailError}
                  helperText={emailError ? "Invalid email format" : ""}
                  fullWidth
                  margin="normal"
                />

                <Button variant="contained" onClick={handleResetPassword}>
                  Reset Password
                </Button>
              </>
            ) : (
              <>
                <p>
                  An email with instructions to reset your password has been
                  sent to your email address.
                </p>

                <Button
                  type="button"
                  variant="contained"
                  sx={{ background: "#7F265B", marginRight: "0.5rem" }}
                  onClick={() => {
                    navigate("/"); // Replace "/login" with the appropriate path to your login page
                  }}
                >
                  Back to Login
                </Button>
              </>
            )}
          </Box>
        </Grid>
      </Grid>
    </div>
  );
}
