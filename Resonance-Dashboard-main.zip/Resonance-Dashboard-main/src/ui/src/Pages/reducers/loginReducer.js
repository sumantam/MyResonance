import { createSlice } from '@reduxjs/toolkit';

const loginSlice = createSlice({
  name: 'login',
  initialState: {
    email: '',
    isLoggedIn: false,
  },
  reducers: {
    setLoginDetails: (state, action) => {
      state.email = action.payload.email;
      state.isLoggedIn = true;
    },
    logout: (state) => {
      state.email = '';
      state.isLoggedIn = false;
    },
  },
});

export const { setLoginDetails, logout } = loginSlice.actions;

export default loginSlice.reducer;
