// reducers.js
import { combineReducers } from 'redux';
import loginReducer from './loginReducer';
import formReducer from './formReducer';

const rootReducer = combineReducers({
  login: loginReducer,
  form: formReducer,
  // Add more reducers if needed
});

export default rootReducer;
