
// import formReducer from './formReducer';
// import loginReducer from './loginReducer';


// const store = configureStore({
//   reducer: {
//     login: loginReducer,
//     form: formReducer
//   },
// });

// export default store;
// store.js
// store.js
import { configureStore } from '@reduxjs/toolkit';
import rootReducer from './rootReducer';

const store = configureStore({
  reducer: rootReducer,
});

export default store;

