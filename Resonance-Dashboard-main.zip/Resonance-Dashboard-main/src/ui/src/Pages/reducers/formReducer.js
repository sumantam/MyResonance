// formReducer.js
import axios from 'axios';
// Action types
export const ADD_USER = 'ADD_USER';
export const DELETE_USER = 'DELETE_USER'; // Add DELETE_USER action type
export const UPDATE_USER = "UPDATE_USER";
export const FETCH_USERS_SUCCESS = "FETCH_USERS_SUCCESS";
export const FETCH_USERS_FAILURE = "FETCH_USERS_FAILURE";

// Action creators
export const addUser = (userData) => {
  return {
    type: ADD_USER,
    payload: userData,
  };
};

export const deleteUser = (userId) => {
  return {
    type: DELETE_USER,
    payload: userId,
  };
};

export const updateUser = (user) => {
  return {
    type: UPDATE_USER,
    payload: user,
  };
};

export const fetchUsersSuccess = (users) => {
  return {
    type: FETCH_USERS_SUCCESS,
    payload: users,
  };
};

export const fetchUsersFailure = (error) => {
  return {
    type: FETCH_USERS_FAILURE,
    payload: error,
  };
};

// export const fetchUsers = () => {
//   console.log("fetchUsers is called");
//   return async (dispatch) => {
//     try {
//       const token = '4870f96b-6590-43ef-bde5-ad20afdf3daa';
//       const response = await fetch("https://36a5-182-73-97-234.ngrok-free.app/api/users", {
//         method: "GET",
//         mode: "cors",
//         headers: {
//           "api_key": token,
//           "Content-Type": "application/json",
//         },
//       });
//       console.log(response.body)
//       if (response.ok) {
//         console.log("hello")
//         const data = await response.json();
//         console.log("this is the data",data);
//         dispatch(fetchUsersSuccess(data));
//       } else {
//         throw new Error("Error101: " + response.status);
//       }
//     } catch (error) {
//       console.error("Error201:", error);
//       dispatch(fetchUsersFailure(error.message));
//     }
//   };
// };

export const fetchUsers = () => {
  console.log("fetchUsers is called");
  return async (dispatch) => {
    try {
      const token = '4870f96b-6590-43ef-bde5-ad20afdf3daa';
      const response = await axios.get("http://localhost:3001/api/users", {
        headers: {
          "api_key": token,
          "Content-Type": "application/json",
          'ngrok-skip-browser-warning':true
        },
      });

      const data = response.data;
      console.log("Response data:", data);
      dispatch(fetchUsersSuccess(data));
    } catch (error) {
      dispatch(fetchUsersFailure(error.message));
    }
  };
};


// Initial state
const initialState = {
  data: [], // Initial state of the data in your store
  error: null,
};

// Reducer function
const formReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_USER:
      return {
        ...state,
        data: [...state.data, action.payload],
      };
    case DELETE_USER: // Handle DELETE_USER action
      return {
        ...state,
        data: state.data.filter((user) => user.username !== action.payload),
      };
    case UPDATE_USER:
      return {
        ...state,
        data: state.data.map((user) =>
          user.email === action.payload.email ? action.payload : user
        ),
      };
    case FETCH_USERS_SUCCESS:
      return {
        ...state,
        data: action.payload,
        error: null,
      };
    case FETCH_USERS_FAILURE:
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default formReducer;
